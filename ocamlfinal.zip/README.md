# Autonomous Crypto Trading Bot
Run `make build`, then `make test` to get trading indications of either `Buy`, `Wait`, or `Sell` based on a user-provided set interval, such as `1` day.
